// script.js

document.addEventListener('DOMContentLoaded', () => {
    // --- 1. Interactive Elements: Accordion for services.html ---
    const accordionHeaders = document.querySelectorAll('.accordion-header');

    accordionHeaders.forEach(header => {
        header.addEventListener('click', () => {
            const item = header.parentElement;
            const content = header.nextElementSibling;
            const icon = header.querySelector('.accordion-icon');

            // Close all other open accordions
            document.querySelectorAll('.accordion-item.active').forEach(activeItem => {
                if (activeItem !== item) {
                    activeItem.classList.remove('active');
                    activeItem.querySelector('.accordion-content').style.maxHeight = null;
                    activeItem.querySelector('.accordion-icon').textContent = '+';
                }
            });

            // Toggle the clicked accordion
            item.classList.toggle('active');
            if (item.classList.contains('active')) {
                content.style.maxHeight = content.scrollHeight + "px";
                icon.textContent = '-';
            } else {
                content.style.maxHeight = null;
                icon.textContent = '+';
            }
        });
    });

    // --- 2. Dynamic Content: Load content for home.html ---
    const dynamicPostsContainer = document.getElementById('dynamic-posts');
    if (dynamicPostsContainer) {
        const posts = [
            { date: 'Sept 15, 2025', title: 'Understanding Stock Market Trends', content: 'Learn to analyze market patterns and identify investment opportunities. Our experts will share insights on current market conditions and future outlook.' },
            { date: 'Sept 22, 2025', title: 'Retirement Planning Strategies', content: 'Discover effective strategies for building a secure retirement portfolio. Learn about 401(k)s, IRAs, and other retirement vehicles to maximize your savings.' },
            { date: 'Oct 1, 2025', title: 'Investment Opportunities in Tech', content: 'Explore the latest trends in technology investments. Learn about emerging sectors, growth potential, and how to evaluate tech companies for your portfolio.' },
            { date: 'Oct 8, 2025', title: 'Tax-Efficient Investing', content: 'Maximize your returns by minimizing taxes. Learn about tax-advantaged accounts, strategies, and timing to optimize your investment outcomes.' },
            { date: 'Oct 15, 2025', title: 'ESG Investing Workshop', content: 'Discover how to align your investments with your values. Learn about Environmental, Social, and Governance investing opportunities and impact.' },
            { date: 'Oct 29, 2025', title: 'Estate Planning Essentials', content: 'Protect your wealth for future generations. Learn about wills, trusts, and estate planning strategies to preserve and transfer your assets effectively.' }
        ];

        const containerDiv = dynamicPostsContainer.querySelector('.container');
        if (containerDiv) {
            // Assuming the H2 is already in the HTML, just append the grid
            containerDiv.innerHTML += `<div class="events-grid">${posts.map(post => `
                <div class="event-card">
                    <div class="event-date">${post.date}</div>
                    <h3>${post.title}</h3>
                    <p>${post.content}</p>
                </div>
            `).join('')}</div>`;
        }
    }

    // --- 3. Interactive Elements: Lightbox Gallery for portfolio.html ---
    const lightbox = document.getElementById('lightbox');
    const lightboxImg = document.getElementById('lightbox-img');
    const lightboxCaption = document.getElementById('lightbox-caption');
    const closeBtn = document.querySelector('.lightbox .close-btn');
    const galleryItems = document.querySelectorAll('.gallery-item');

    galleryItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            lightbox.style.display = 'flex'; // Use flex to center content
            lightboxImg.src = item.href;
            lightboxCaption.innerHTML = item.dataset.caption;
        });
    });

    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            lightbox.style.display = 'none';
        });
    }

    if (lightbox) {
        lightbox.addEventListener('click', (e) => {
            // Close if clicking on the overlay, not the image or caption
            if (e.target === lightbox || e.target === closeBtn) {
                lightbox.style.display = 'none';
            }
        });
    }

    // --- 4. Dynamic Content: Search/Filter for services.html (Simulated) ---
    // Since services.html has a list of services, I will implement a filter/sort for those.
    const servicesSection = document.querySelector('.services-section');
    if (servicesSection) {
        // Inject search/sort controls
        const controlsHTML = `
            <div class="filter-controls">
                <input type="text" id="service-search" placeholder="Search services...">
                <select id="service-sort">
                    <option value="default">Sort By: Default</option>
                    <option value="title-asc">Title (A-Z)</option>
                    <option value="title-desc">Title (Z-A)</option>
                </select>
            </div>
        `;
        servicesSection.querySelector('.container').insertAdjacentHTML('afterbegin', controlsHTML);

        const searchInput = document.getElementById('service-search');
        const sortSelect = document.getElementById('service-sort');
        const serviceCardsContainer = document.querySelector('.services-grid');
        const serviceCards = Array.from(document.querySelectorAll('.services-grid .service-card'));

        const filterAndSortServices = () => {
            const searchTerm = searchInput.value.toLowerCase();
            const sortBy = sortSelect.value;

            let filteredCards = serviceCards.filter(card => {
                const title = card.querySelector('h3').textContent.toLowerCase();
                const description = card.querySelector('p').textContent.toLowerCase();
                return title.includes(searchTerm) || description.includes(searchTerm);
            });

            if (sortBy === 'title-asc') {
                filteredCards.sort((a, b) => a.querySelector('h3').textContent.localeCompare(b.querySelector('h3').textContent));
            } else if (sortBy === 'title-desc') {
                filteredCards.sort((a, b) => b.querySelector('h3').textContent.localeCompare(a.querySelector('h3').textContent));
            }

            // Clear current cards and append filtered/sorted ones
            serviceCardsContainer.innerHTML = '';
            if (filteredCards.length === 0) {
                serviceCardsContainer.innerHTML = '<p class="no-results">No services found matching your search criteria.</p>';
            } else {
                filteredCards.forEach(card => serviceCardsContainer.appendChild(card));
            }
        };

        searchInput.addEventListener('input', filterAndSortServices);
        sortSelect.addEventListener('change', filterAndSortServices);
    }

    // --- 5. Form Functionality and Validation (Client-Side, Error Handling, AJAX Submission) ---
    const contactForm = document.querySelector('.contact-form-section form');
    const enquiryForm = document.querySelector('.enquiry-form-section form');

    const setupFormValidation = (form) => {
        if (!form) return;

        form.setAttribute('novalidate', true); // Disable default HTML5 validation for custom handling

        const submitFormAjax = (form) => {
            const formData = new FormData(form);
            const formObject = {};
            formData.forEach((value, key) => {
                formObject[key] = value;
            });

            // Simulate an AJAX request
            console.log('Form Data to be sent:', formObject);

            // Display a success message
            const successMessage = document.createElement('div');
            successMessage.className = 'success-message';
            successMessage.textContent = `Thank you for your ${form.id === 'contactForm' ? 'message' : 'enquiry'}! We have received your submission and will be in touch shortly.`;
            
            // Remove previous messages
            const existingMessage = form.parentElement.querySelector('.success-message, .error-message-server');
            if (existingMessage) {
                existingMessage.remove();
            }

            form.insertAdjacentElement('beforebegin', successMessage);
            form.reset();
            
            // In a real application, you would use fetch() or XMLHttpRequest here
        };

        const validateForm = (event) => {
            let isValid = true;
            const formGroups = form.querySelectorAll('.form-group');

            // Clear all previous errors
            form.querySelectorAll('.error-message').forEach(el => el.remove());
            form.querySelectorAll('.input-error').forEach(el => el.classList.remove('input-error'));

            formGroups.forEach(group => {
                const input = group.querySelector('input, select, textarea');
                if (!input) return;

                let errorText = '';

                if (input.hasAttribute('required') && input.value.trim() === '') {
                    errorText = 'This field is required.';
                } else if (input.type === 'email' && input.value.trim() !== '' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value)) {
                    errorText = 'Please enter a valid email address.';
                } else if (input.id === 'phone' && input.value.trim() !== '' && !/^\+?(\d.*){3,}$/.test(input.value)) {
                    // Simple phone validation: starts with optional + and has at least 3 digits
                    errorText = 'Please enter a valid phone number (at least 3 digits).';
                } else if (input.id === 'message' && input.value.trim().length < 10) {
                    errorText = 'Message must be at least 10 characters long.';
                } else if (input.id === 'enquiryType' && input.value === '') {
                    errorText = 'Please select an enquiry type.';
                }

                if (errorText) {
                    const errorElement = document.createElement('div');
                    errorElement.className = 'error-message';
                    errorElement.textContent = errorText;
                    group.appendChild(errorElement);
                    input.classList.add('input-error');
                    isValid = false;
                }
            });

            if (!isValid) {
                event.preventDefault();
                // Scroll to the first error
                const firstError = form.querySelector('.input-error');
                if (firstError) {
                    firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
            } else {
                // AJAX Form Submission
                event.preventDefault();
                submitFormAjax(form);
            }
        };

        form.addEventListener('submit', validateForm);
    };

    setupFormValidation(contactForm);
    setupFormValidation(enquiryForm);

    // --- 7. Interactive Map (Leaflet) for contact.html and enquiry.html ---
    const mapElement = document.getElementById('map');
    if (mapElement) {
        // Coordinates for Polokwane, South Africa (approximate center)
        const polokwaneLat = -23.9058333;
        const polokwaneLng = 29.4613889;
        const officeLat = -23.9058333; // Using the same for now
        const officeLng = 29.4613889; // Using the same for now

        const map = L.map('map').setView([officeLat, officeLng], 15);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        L.marker([officeLat, officeLng]).addTo(map)
            .bindPopup('Robs Investments Holdings Office<br>244 Suid Street, Polokwane')
            .openPopup();
    }

    // --- 6. Add animations and transitions using CSS and JavaScript (Requirement 2.3) ---
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });

    document.querySelectorAll('main section').forEach(element => {
        // Exclude the hero section from the animation
        if (!element.classList.contains('hero')) {
            observer.observe(element);
        }
    });
});
